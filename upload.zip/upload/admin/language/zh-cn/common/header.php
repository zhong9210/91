<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-22 09:12:56
 * @modified         2016-11-05 17:35:21
 */

// Heading
$_['heading_title']      = 'OpenCart';

// Text
$_['text_profile']       = '账号信息';

$_['text_store']         = '网店名称';
$_['text_help']          = '帮助';
$_['text_homepage']      = '技术支持';
$_['text_support']       = '技术论坛';
$_['text_documentation'] = '支持文档';
$_['text_logout']        = '退出登录';
$_['text_sort']          = '排序';
$_['text_delete']        = '删除';
$_['text_delete']        = '删除';
$_['text_main_image']    = '设置为主图';
