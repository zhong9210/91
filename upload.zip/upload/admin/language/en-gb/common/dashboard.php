<?php
// Heading
$_['heading_title'] = 'Dashboard';

$_['footer_btn_close']                = 'Close';
$_['footer_btn_link']                = 'To watch';

// Error
$_['error_install'] = 'Warning: Install folder still exists and should be deleted for security reasons!';