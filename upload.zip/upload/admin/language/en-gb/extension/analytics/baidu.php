<?php
$_['heading_title']    = 'Baidu Tongji';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Baidu Tongji!';
$_['text_edit']        = 'Edit Baidu Tongji';
$_['text_signup']      = 'Login to your <a href="http://tongji.baidu.com/" target="_blank"><u>Baidu Tongji</u></a> account and after creating your website profile copy and paste the analytics code into this field.';
$_['text_default']     = 'Default';

// Entry
$_['entry_code']       = 'Baidu Tongji Code';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Baidu Tongji!';
$_['error_code']	   = 'Code required!';
