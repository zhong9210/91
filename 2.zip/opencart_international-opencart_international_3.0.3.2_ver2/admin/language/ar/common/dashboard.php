<?php
// Heading
$_['heading_title']    = 'لوحة التحكم';

// Error
$_['error_install']    = 'تحذير: لم يتم حذف مجلد التنصيب - ويجب حذفه لأمان المتجر!';
