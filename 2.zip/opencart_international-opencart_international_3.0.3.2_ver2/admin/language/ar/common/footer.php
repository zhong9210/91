<?php
// Text
$_['text_footer'] = '<a href="http://www.mycncart.com" target="_blank">MyCnCart</a>&nbsp;&nbsp;<a href="http://www.opencart.com" target="_blank">OpenCart</a> &copy; 2009 - ' . date('Y') . ' جميع الحقوق محفوظةترجمة ';
$_['text_version'] 	= 'الاصدار رقم %s';